import cv2
import sys
import RPi.GPIO as gp
import time

model = "haarcascade_frontalface_default.xml"


faceCascade = cv2.CascadeClassifier(model)
video_capture = cv2.VideoCapture(0)


led_pin = 2
gp.setmode(gp.BCM)
gp.setup(led_pin,gp.OUT)

while True:
    ret, frame = video_capture.read()
    frame = cv2.resize(frame,(600,400))
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = faceCascade.detectMultiScale(gray,scaleFactor=1.3)
    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
        print(len(faces))
        
    if len(faces) >=1:
        gp.output(led_pin, gp.HIGH)
        print('LED ON')
        time.sleep(2)
        gp.output(led_pin, gp.LOW)
        print('LED OFF')
        time.sleep(1)
        
    cv2.imshow('Video', frame)
    if cv2.waitKey(1) == ord('q'):
        break

video_capture.release()
cv2.destroyAllWindows()